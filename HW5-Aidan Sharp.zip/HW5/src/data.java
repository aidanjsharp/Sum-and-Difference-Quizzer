import java.util.Random;

public class data {
	public int RNG(){
		Random rand = new Random();
		int int_random = rand.nextInt(10);					//randomly generates an integer 0-9
	
		
		return int_random;

	
	}
}